# NOVA RETAIL — Business Intelligence | Dashboard de Vendas

Projeto acadêmico de **Business Intelligence com Power BI, DAX, Power Query (M), MySQL e modelagem Star Schema**. Inspirado no conteúdo da **Aula 07 — Business Intelligence: Star Schema**, com melhorias de layout e indicadores.

> **Atenção:** a marca NOVA RETAIL, os clientes e todas as vendas são **fictícios**. Não há senhas ou dados pessoais reais no repositório. O dashboard HTML abaixo é uma **prévia interativa independente**, e não substitui o relatório nativo Power BI.

![Prévia do dashboard](docs/dashboard_preview.png)

## Comece em 1 clique (Windows)

- `ABRIR_POWER_BI.bat`: abre o projeto PBIP no Power BI Desktop instalado.
- `ENVIAR_GITHUB_SEM_GIT.bat`: abre seu repositório e a pasta para arrastar os arquivos, sem instalar nada.
- `PUBLICAR_GITHUB.bat`: tenta localizar/instalar o Git e enviar os arquivos para o repositório GitHub já criado, com autenticação no navegador se necessária.
- `COMECE_AQUI.txt`: roteiro curto de abertura, upload pelo navegador (sem Git), MySQL e entrega para o professor.

**Sem Git instalado?** Acesse diretamente [Upload files](https://github.com/kaiquestracieri-arch/nova-retail-business-intelligence/upload/main) e envie o conteúdo descompactado desta pasta. Este projeto mantém a estrutura de subpastas do PBIP.

## Abrir o projeto

1. Instale a versão atual do **Power BI Desktop (Windows)**.
2. Extraia o ZIP completo, **sem mover apenas um arquivo `.pbip`**.
3. Abra `NOVA_RETAIL.pbip` com o Power BI Desktop.
4. O modo inicial **pUsarMySQL = false** usa amostras incorporadas no Power Query. Clique em **Página Inicial > Atualizar** para carregar os dados, caso o aplicativo solicite.
5. Para trocar para banco real, crie as tabelas pelo arquivo `sql/01_criar_banco_e_popular.sql` no MySQL Workbench. Em **Transformar dados > Gerenciar parâmetros**, mude `pUsarMySQL` para `true`, e ajuste `pServidor`/`pBanco`; informe as credenciais **somente na janela local de acesso**.
6. Caso deseje um arquivo PBIX final, no Power BI Desktop escolha **Arquivo > Salvar como > Power BI (.pbix)** após a primeira atualização.

**Importante:** este pacote contém um projeto editável **PBIP + PBIR + modelo semântico TMSL**, não um `.pbix` compilado. A estrutura e os dados foram verificados por script, mas a abertura no Power BI Desktop precisa ser confirmada no Windows. Se a versão instalada do Desktop não reconhecer PBIP/PBIR, atualize o aplicativo antes de testar. Não foi possível executar o próprio Power BI Desktop neste ambiente.

## Prévia interativa, mesmo sem Power BI

Abra `preview_dashboard.html` (ou `index.html`) no Chrome/Edge. Os filtros, gráficos, KPIs e a segunda página já funcionam **offline**, usando a mesma base fictícia. O arquivo HTML serve para documentação e portfólio; sua implementação é independente dos visuais nativos do `.pbip`.

![Página de produtos e clientes](docs/dashboard_produtos.png)

## Arquitetura

![Diagrama Star Schema](docs/modelo_estrela.svg)

- **Fato:** `fat_vendas`, no nível de item vendido, 2.600 linhas de exemplo.
- **Dimensões:** `dim_produtos` (24), `dim_clientes` (120), `dim_fornecedores` (6), `dim_datas` (1.035) e `dim_canais` (4).
- **Relacionamentos:** dimensão (1) → fato (N); direção única; integridade por chave estrangeira MySQL.
- **Power Query:** arquivos M explícitos, importação SQL parametrizada e dados de demonstração compactados.
- **Medidas DAX:** 15 medidas, incluindo Total de Vendas, Lucro, Ticket Médio, Crescimento YoY, YTD e Participação.
- **Relatórios PBIR:** 2 páginas de visuais nativos, com KPIs, tendências, gráficos de barras, rosca, segmentações e tabela.

## Tecnologias

`Power BI Desktop` · `PBIP/PBIR` · `TMSL` · `Power Query M` · `DAX` · `MySQL 8` · `SQL` · `HTML/CSS/JS` · `Git/GitHub`

## Estrutura do repositório

```text
NOVA_RETAIL.pbip              # Abrir este arquivo no Power BI Desktop
NOVA_RETAIL.Report/           # Layout nativo PBIR (2 páginas)
NOVA_RETAIL.SemanticModel/    # Modelo Tabular, relações, medidas e Power Query
sql/                          # Banco MySQL: criação, dados e consultas analíticas
power_query/                  # Scripts M de todas as tabelas
dax/                         # Copiável: 15 medidas DAX
 dados/                       # CSVs fictícios para auditoria
preview_dashboard.html        # Dashboard interativo que funciona no navegador
tema_powerbi.json            # Tema escuro
 docs/                        # Capturas, modelo e tutoriais
scripts/                      # Validação automatizada
.github/workflows/            # Verificação CI no GitHub Actions
```

## Indicadores e resultados

A base demonstrativa tem faturamento acumulado de **R$ 2.921.446,62**, custo total de **R$ 1.823.903,00** e lucro bruto de **R$ 1.097.543,62** entre janeiro de 2024 e outubro de 2026. São números gerados artificialmente, não representam uma empresa real.

## Validação

Com Python 3 instalado, execute na pasta do projeto:

```bash
python scripts/validar_projeto.py
```

O script verifica a integridade entre fatos/dimensões, as quantias principais, a sintaxe JSON e as referências de campos em visuais PBIR. Para validar a renderização em Power BI Desktop é necessária uma instalação local em Windows.

## Guias

- [Abrir e conectar MySQL](docs/COMO_ABRIR_E_CONECTAR.md)
- [Publicar no GitHub](docs/COMO_PUBLICAR_NO_GITHUB.md)
- [Modelo e DAX](docs/ARQUITETURA_E_MEDIDAS.md)

---

*Projeto acadêmico independente, alinhado aos conceitos de BI/Star Schema da aula fornecida; não é um material oficial da instituição.*
