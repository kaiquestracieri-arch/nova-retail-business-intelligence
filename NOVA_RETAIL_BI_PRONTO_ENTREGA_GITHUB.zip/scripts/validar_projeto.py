#!/usr/bin/env python3
"""Validação offline de JSON, dados e referências do projeto NOVA RETAIL."""
import csv, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]

def table(name):
    with (ROOT/'dados'/f'{name}.csv').open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f,delimiter=';'))

def main():
    assert (ROOT/'NOVA_RETAIL.pbip').is_file()
    files=list(ROOT.rglob('*.json'))+[ROOT/'NOVA_RETAIL.pbip',ROOT/'NOVA_RETAIL.Report'/'definition.pbir',ROOT/'NOVA_RETAIL.SemanticModel'/'definition.pbism',ROOT/'NOVA_RETAIL.SemanticModel'/'model.bim']
    for p in files:
        json.loads(p.read_text(encoding='utf-8'))
    model=json.loads((ROOT/'NOVA_RETAIL.SemanticModel'/'model.bim').read_text(encoding='utf-8'))['model']
    facts=table('fat_vendas')
    assert len(facts)==2600
    refs={tab:{r[key] for r in table(tab)} for tab,key in [('dim_datas','data_id'),('dim_produtos','produto_id'),('dim_clientes','cliente_id'),('dim_fornecedores','fornecedor_id'),('dim_canais','canal_id')]}
    for row in facts:
        for table_name,ids in refs.items():
            col={'dim_datas':'data_id','dim_produtos':'produto_id','dim_clientes':'cliente_id','dim_fornecedores':'fornecedor_id','dim_canais':'canal_id'}[table_name]
            assert row[col] in ids, ('FK inexistente',row,col)
        assert abs(float(row['valor_bruto'])*(1-float(row['desconto_pct']))-float(row['valor_liquido']))<0.02
    total=round(sum(float(row['valor_liquido']) for row in facts),2)
    profit=round(sum(float(row['valor_liquido'])-float(row['custo_total']) for row in facts),2)
    assert total==2921446.62 and profit==1097543.62,(total,profit)
    names={t['name'] for t in model['tables']}
    assert names=={'dim_datas','dim_produtos','dim_clientes','dim_fornecedores','dim_canais','fat_vendas'}
    cols={t['name']:{c['name'] for c in t['columns']} for t in model['tables']}
    measures={m['name'] for t in model['tables'] for m in t.get('measures',[])}
    assert len(measures)==15
    for rel in model['relationships']:
        assert rel['fromTable'] in cols and rel['toTable'] in cols
        assert rel['fromColumn'] in cols[rel['fromTable']] and rel['toColumn'] in cols[rel['toTable']]
    pbir_root=ROOT/'NOVA_RETAIL.Report'/'definition'/'pages'
    pages=json.loads((pbir_root/'pages.json').read_text(encoding='utf-8'))
    count=0
    for p in pages['pageOrder']:
        assert (pbir_root/p/'page.json').is_file()
        for file in (pbir_root/p/'visuals').glob('*/visual.json'):
            v=json.loads(file.read_text(encoding='utf-8'))['visual'];count+=1
            for well in v.get('query',{}).get('queryState',{}).values():
                for proj in well.get('projections',[]):
                    f=proj['field'];type_,ref=next(iter(f.items()))
                    entity=ref['Expression']['SourceRef']['Entity'];property_=ref['Property']
                    assert entity in names,(file,entity)
                    assert property_ in (measures if type_=='Measure' else cols[entity]),(file,property_)
    assert count>=15,count
    print(f'VALIDO: {len(files)} JSONs; {count} visuais; {len(measures)} medidas; {len(facts)} vendas; R$ {total:.2f}; lucro R$ {profit:.2f}; nenhuma FK ausente.')

if __name__=='__main__':
    try:main()
    except Exception as e: print('ERRO NA VALIDACAO:',e);sys.exit(1)
