# Publicador do projeto NOVA RETAIL para GitHub (Windows / PowerShell 5.1+)
# Repositorio criado antecipadamente na conta do aluno.
# Autenticacao do GitHub ocorre pelo navegador via Git Credential Manager.
$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/kaiquestracieri-arch/nova-retail-business-intelligence.git'
$web = 'https://github.com/kaiquestracieri-arch/nova-retail-business-intelligence'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $project

function Find-Git {
    $found = Get-Command 'git.exe' -ErrorAction SilentlyContinue
    if ($found) { return $found.Source }
    $locations = @(
        "$env:ProgramFiles\Git\cmd\git.exe",
        "${env:ProgramFiles(x86)}\Git\cmd\git.exe",
        "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe",
        "$env:LOCALAPPDATA\Git\cmd\git.exe"
    )
    foreach ($location in $locations) {
        if ($location -and (Test-Path -LiteralPath $location)) { return $location }
    }
    return $null
}

function Git {
    & $script:gitPath @args
    if ($LASTEXITCODE -ne 0) { throw "Falha em git $($args -join ' ') (codigo $LASTEXITCODE)." }
}

Write-Host ''
Write-Host '===================================================' -ForegroundColor Cyan
Write-Host '  NOVA RETAIL - Publicacao no GitHub' -ForegroundColor Cyan
Write-Host '===================================================' -ForegroundColor Cyan
Write-Host "Pasta: $project"
Write-Host "Destino: $web"
Write-Host ''

try {
    if (!(Test-Path -LiteralPath (Join-Path $project 'NOVA_RETAIL.pbip'))) {
        throw 'O arquivo NOVA_RETAIL.pbip nao foi encontrado. Execute a partir da pasta extraida do ZIP.'
    }
    $script:gitPath = Find-Git
    if (!$script:gitPath) {
        $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue
        if ($winget) {
            Write-Host 'Git nao encontrado. Tentando instalar via winget para o usuario atual...' -ForegroundColor Yellow
            & $winget.Source install --id Git.Git --exact --source winget --scope user --accept-source-agreements --accept-package-agreements --silent
            if ($LASTEXITCODE -ne 0) {
                Write-Host 'A instalacao automatica nao foi concluida. Tentarei detectar o Git novamente.' -ForegroundColor Yellow
            }
            $script:gitPath = Find-Git
        }
    }
    if (!$script:gitPath) {
        Write-Host ''
        Write-Host 'Nao foi possivel encontrar o Git.' -ForegroundColor Red
        Write-Host 'Alternativa sem Git: abra o link abaixo, clique em Add file > Upload files,'
        Write-Host 'e arraste todos os arquivos e pastas DENTRO desta pasta extraida.'
        Write-Host "  $web/upload/main"
        Start-Process "${web}/upload/main"
        throw 'Publicacao automatica interrompida porque o Git nao esta disponivel.'
    }
    Write-Host "Usando: $script:gitPath" -ForegroundColor Green
    Git --version
    if (!(Test-Path -LiteralPath (Join-Path $project '.git'))) { Git init }
    Git config user.name 'kaiquestracieri-arch'
    # Endereco noreply para nao expor email pessoal em commits.
    Git config user.email '355647406+kaiquestracieri-arch@users.noreply.github.com'
    Git add -A
    # Cria commit somente quando ha mudancas no indice.
    & $script:gitPath diff --cached --quiet
    if ($LASTEXITCODE -eq 1) {
        Git commit -m 'Projeto Business Intelligence NOVA RETAIL - Star Schema'
    } elseif ($LASTEXITCODE -ne 0) {
        throw 'Nao foi possivel verificar as mudancas preparadas.'
    } else {
        Write-Host 'Todos os arquivos ja estao registrados localmente.'
    }
    Git branch -M main
    & $script:gitPath remote get-url origin *> $null
    if ($LASTEXITCODE -eq 0) { Git remote set-url origin $repo }
    else { Git remote add origin $repo }
    Write-Host ''
    Write-Host 'Abrindo envio para o GitHub. Se aparecer login, entre com sua conta no navegador.' -ForegroundColor Yellow
    Git push -u origin main
    Write-Host ''
    Write-Host 'PUBLICADO COM SUCESSO!' -ForegroundColor Green
    Write-Host $web -ForegroundColor Cyan
    Start-Process $web
} catch {
    Write-Host ''
    Write-Host "PUBLICACAO NAO CONCLUIDA: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Opcao sem comandos: abra o link abaixo e faca upload dos arquivos descompactados:'
    Write-Host "${web}/upload/main"
}
Write-Host ''
Read-Host 'Pressione ENTER para fechar esta janela'
