@echo off
cd /d "%~dp0"
echo Abrindo a pagina de upload do seu repositorio...
start "" "https://github.com/kaiquestracieri-arch/nova-retail-business-intelligence/upload/main"
echo Abrindo a pasta do projeto para voce arrastar os arquivos...
explorer.exe "%~dp0"
echo.
echo Arraste TODOS os itens desta pasta para a pagina do GitHub,
echo confira os arquivos e clique em Commit changes.
pause
