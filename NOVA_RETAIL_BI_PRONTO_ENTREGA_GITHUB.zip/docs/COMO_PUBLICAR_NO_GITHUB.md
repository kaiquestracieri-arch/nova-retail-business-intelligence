# Como publicar o projeto no GitHub

## Método 1 — pelo navegador (mais simples)

1. Entre em https://github.com/ e acesse sua conta.
2. Clique em **+ > New repository** ou em https://github.com/new.
3. Nome: `nova-retail-business-intelligence` (ou o nome que preferir).
4. Descrição: `Dashboard Power BI de vendas com MySQL, modelo estrela, Power Query e DAX`.
5. Selecione **Public** para colocar no portfólio. Não marque README/licença/.gitignore, pois o projeto já tem esses arquivos.
6. Clique **Create repository**.
7. Entre na opção **uploading an existing file** / **Add file > Upload files**.
8. Descompacte o ZIP no seu computador. Arraste o **conteúdo completo** da pasta (inclusive `.Report`, `.SemanticModel`, `docs`, `sql`, etc.) para a área de upload. Atenção: em alguns navegadores, pastas arrastadas podem não ser aceitas. Nesse caso use o Método 2 para preservar a estrutura.
9. Digite `Dashboard BI completo` no campo de commit e clique **Commit changes**.
10. Abra o link do repositório. O GitHub irá mostrar o README e as imagens do dashboard na página inicial.

## Método 2 — pelo terminal do VS Code (preserva a estrutura)

1. Crie um repositório **vazio** no GitHub (etapas 1–6 acima).
2. Instale o Git (https://git-scm.com/downloads), se ainda não tiver.
3. No Windows, extraia o ZIP, abra a pasta `BI_Vendas_Star_GitHub` no **VS Code** e abra **Terminal > Novo Terminal**.
4. Copie os comandos abaixo, trocando `SEU_USUARIO` pelo seu usuário do GitHub:

```bash
git init
git add .
git commit -m "Projeto BI: dashboard Power BI + MySQL + DAX"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/nova-retail-business-intelligence.git
git push -u origin main
```

5. O GitHub pode solicitar login no navegador, Git Credential Manager ou um token. Não insira senha pessoal em arquivos de projeto.
6. Atualize a página do repositório e confira o `README.md` e a pasta `.Report`.

### Atualizar depois de editar o BI

```bash
git add .
git commit -m "Atualiza dashboard e medidas"
git push
```

### Atenção ao tamanho e segurança

- Suba o **conteúdo extraído**, não apenas o ZIP ou o arquivo `.pbip` sozinho.
- `.gitignore` já evita arquivos de cache `.pbi`, credenciais `.env` e PBIX compilado por padrão.
- Não envie arquivos com senhas MySQL, chaves de API ou dados de clientes reais.
- O GitHub **não executa Power BI Desktop**. A prévia `preview_dashboard.html` é navegável se baixada e aberta no navegador; imagens ficam visíveis diretamente no README.
- Se quiser hospedar a prévia online, configure GitHub Pages na branch principal e use **Settings > Pages > Deploy from a branch > main / root**. O arquivo `index.html` já está na raiz e será usado automaticamente como página inicial.
