# Abrir no Power BI e conectar ao MySQL

## Primeiro acesso — sem configurar banco

1. Descompacte a pasta inteira, não abra o PBIP dentro do ZIP.
2. No Windows, com o Power BI Desktop atualizado, clique duas vezes em **NOVA_RETAIL.pbip**.
3. Na primeira abertura, a prévia das tabelas pode aparecer sem dados até você clicar em **Atualizar**.
4. Em **Transformar dados > Gerenciar parâmetros**, confirme que `pUsarMySQL` está **false**. Esse é o modo demonstrativo, que contém os 2.600 registros incorporados no próprio modelo e não precisa de MySQL.
5. Confirme que as 6 tabelas estão carregadas e que a página **01 | Visao Geral** tem os KPIs.
6. Para um arquivo único, depois de atualizar, use **Arquivo > Salvar como** e escolha `.pbix` (se esta opção estiver disponível no seu Power BI).

> `.pbip` é um projeto de desenvolvimento composto por pastas. Sem as pastas `.Report` e `.SemanticModel` ele não funciona.

## Conexão com banco MySQL no Workbench

1. Instale/abra **MySQL Server 8.0+** e **MySQL Workbench**. O servidor deve estar em execução.
2. No Workbench, abra `sql/01_criar_banco_e_popular.sql`.
3. Clique no raio **Execute** (ou Ctrl+Shift+Enter, dependendo do editor). O banco será criado como `bi_vendas_star`.
4. Confirme com:

```sql
USE bi_vendas_star;
SELECT COUNT(*) AS linhas FROM fat_vendas;
-- Esperado: 2600
```

5. No Power BI Desktop, acesse **Página Inicial > Transformar dados > Gerenciar parâmetros**.
6. Ajuste `pServidor` = `localhost:3306` e `pBanco` = `bi_vendas_star`. Mude `pUsarMySQL` para **true**.
7. Se o Desktop pedir, instale o driver **MySQL Connector/NET** suportado pelo Power BI e reinicie o Power BI.
8. Em **Configurações da fonte de dados**, informe usuário/senha **localmente**; nunca coloque senha em arquivo M, no repositório, ou em screenshot.
9. Se surgir aviso de consulta nativa, confirme somente após inspecionar o SQL contido no projeto.
10. Clique **Fechar e Aplicar** e depois **Atualizar**.

## Se algo der errado

- **Não abre PBIP / visualizações não carregam:** atualize o Power BI Desktop e deixe a estrutura de pastas intacta. O PBIR editável exige versão recente do aplicativo.
- **Erro de conexão:** teste `SELECT 1;` no Workbench, confira MySQL rodando e a porta `3306`, confira usuário/senha em Configurações da fonte de dados.
- **Falta driver:** instale o MySQL Connector/NET adequado para sua versão do Power BI, reinicie o programa.
- **Tela branca / sem valores:** mantenha `pUsarMySQL = false` e use Atualizar; depois confira o Power Query e as mensagens de erro em uma tabela específica.
- **PC da faculdade bloqueia instalação:** use a prévia `preview_dashboard.html` em um navegador. Para abrir um `.pbip` nativo, o Power BI Desktop já precisa estar instalado no Windows.
- **Alterou dados, mas não refletiu:** repita Atualizar no Power BI; prévia HTML usa a amostra embarcada e não lê o servidor MySQL.

**Limitação de teste:** este projeto foi gerado e validado estruturalmente fora do Power BI Desktop; pode ser necessário um ajuste de versão/tema após a primeira abertura local. Sem uma instalação do programa aqui não é possível afirmar que um `.pbix` foi gerado/testado.
