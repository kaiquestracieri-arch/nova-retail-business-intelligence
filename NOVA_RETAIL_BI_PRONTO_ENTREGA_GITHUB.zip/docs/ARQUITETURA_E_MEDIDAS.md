# Modelo estrela, Power Query e medidas DAX

## 1. Problema de negócio

A empresa fictícia NOVA RETAIL precisa acompanhar faturamento, lucro, margem, ticket médio, canais de venda, produtos, clientes e evolução do desempenho no tempo.

## 2. Modelagem Star Schema

O centro do modelo é `fat_vendas`, com **um registro por item de venda**. Há cinco dimensões conectadas: `dim_produtos`, `dim_clientes`, `dim_fornecedores`, `dim_datas` e `dim_canais`.

Cada chave da fato aponta para uma chave primária da dimensão correspondente. Os relacionamentos foram planejados como **1 para muitos** e **filtro unidirecional da dimensão para fato**.

## 3. Power Query — ETL

1. **Extração:** parâmetro `pUsarMySQL` seleciona MySQL (`true`) ou dados demonstrativos incorporados (`false`).
2. **Transformação:** `Table.TransformColumnTypes` padroniza tipos de datas, número inteiro, texto e moeda; remove registros com chave nula.
3. **Carga:** cada consulta é uma partição `import` no modelo semântico do Power BI.

Todos os scripts podem ser lidos individualmente na pasta `power_query/`.

## 4. Medidas DAX comentadas

```dax
Total de Vendas =
SUM('fat_vendas'[valor_liquido])

Quantidade Vendida =
SUM('fat_vendas'[quantidade])

Total de Pedidos =
DISTINCTCOUNT('fat_vendas'[venda_id])

Ticket Medio =
DIVIDE([Total de Vendas], [Total de Pedidos], 0)

Custo Total =
SUM('fat_vendas'[custo_total])

Lucro Bruto =
[Total de Vendas] - [Custo Total]

Margem de Lucro % =
DIVIDE([Lucro Bruto], [Total de Vendas], 0)

Clientes Ativos =
DISTINCTCOUNT('fat_vendas'[cliente_id])

Vendas Ano Anterior =
CALCULATE([Total de Vendas], DATEADD('dim_datas'[data], -1, YEAR))

Crescimento YoY % =
VAR Atual = [Total de Vendas]
VAR Anterior = [Vendas Ano Anterior]
RETURN DIVIDE(Atual - Anterior, Anterior, BLANK())

Vendas YTD =
TOTALYTD([Total de Vendas], 'dim_datas'[data])
```

As 15 medidas completas estão em `dax/medidas.dax` e também no modelo `NOVA_RETAIL.SemanticModel/model.bim`.

## 5. Visuais do relatório

**Página 01 — Visão Geral:** cartões de faturamento, lucro, margem e ticket; linha mensal; rosca de canais; barras por categoria, UF e produto; segmentações por ano, categoria e UF.

**Página 02 — Produtos e Clientes:** itens, pedidos, clientes e evolução anual; margem por produto; receita vs lucro mensal; tabela de clientes; composição de lucro por categoria.

## 6. Referência da disciplina

Material de aula fornecido: **Aula 07 — Business Intelligence: Star Schema**, especialmente as páginas 3–8 (estrela, banco MySQL, tabela fato e medidas DAX) e 9–16 (montagem e aparência do dashboard). Este projeto adota os mesmos conceitos, com dados e design originais.
