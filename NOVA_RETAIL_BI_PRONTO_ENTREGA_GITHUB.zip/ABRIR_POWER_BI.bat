@echo off
cd /d "%~dp0"
if not exist "NOVA_RETAIL.pbip" (
  echo ERRO: NOVA_RETAIL.pbip nao encontrado nesta pasta.
  pause
  exit /b 1
)
echo Abrindo NOVA_RETAIL.pbip no Power BI Desktop...
start "" "NOVA_RETAIL.pbip"
echo Se nao abrir, verifique se o Power BI Desktop esta instalado.
pause
