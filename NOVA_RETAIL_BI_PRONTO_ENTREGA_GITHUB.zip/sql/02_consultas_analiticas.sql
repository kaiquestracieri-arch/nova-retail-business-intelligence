USE bi_vendas_star;
-- Resumo geral
SELECT COUNT(*) pedidos, SUM(quantidade) itens, ROUND(SUM(valor_liquido),2) receita,
       ROUND(SUM(valor_liquido-custo_total),2) lucro,
       ROUND(100*SUM(valor_liquido-custo_total)/NULLIF(SUM(valor_liquido),0),2) margem_pct
FROM fat_vendas;

-- Vendas por mes
SELECT d.ano_mes, ROUND(SUM(v.valor_liquido),2) AS receita
FROM fat_vendas v INNER JOIN dim_datas d ON v.data_id=d.data_id
GROUP BY d.ano_mes ORDER BY d.ano_mes;

-- Top produtos
SELECT p.produto_nome, p.categoria, ROUND(SUM(v.valor_liquido),2) receita
FROM fat_vendas v INNER JOIN dim_produtos p ON v.produto_id=p.produto_id
GROUP BY p.produto_id,p.produto_nome,p.categoria ORDER BY receita DESC LIMIT 10;

-- Prova da integridade do star schema
SELECT COUNT(*) AS fatos_sem_dimensao FROM fat_vendas v
LEFT JOIN dim_datas d ON v.data_id=d.data_id
LEFT JOIN dim_produtos p ON v.produto_id=p.produto_id
LEFT JOIN dim_clientes c ON v.cliente_id=c.cliente_id
LEFT JOIN dim_fornecedores f ON v.fornecedor_id=f.fornecedor_id
LEFT JOIN dim_canais a ON v.canal_id=a.canal_id
WHERE d.data_id IS NULL OR p.produto_id IS NULL OR c.cliente_id IS NULL
   OR f.fornecedor_id IS NULL OR a.canal_id IS NULL;
